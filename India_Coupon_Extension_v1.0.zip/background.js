// Background Service Worker

chrome.runtime.onInstalled.addListener(() => {
    // Initialize default local storage schema
    chrome.storage.local.get(null, (data) => {
        const defaultStorage = {
            enabled: true,
            theme: "light",
            disabledSites: [],
            couponCache: {},
            lastShown: {},
            cooldowns: {}
        };
        const newData = { ...defaultStorage, ...data };
        chrome.storage.local.set(newData);
        console.log("Extension installed and storage initialized.");
    });
});

// Function to check and update cache
const CACHE_DURATION_MS = 6 * 60 * 60 * 1000; // 6 hours

async function getCouponsForDomain(domain) {
    return new Promise((resolve) => {
        chrome.storage.local.get(['couponCache'], (result) => {
            const cache = result.couponCache || {};
            const siteCache = cache[domain];
            
            const now = Date.now();
            
            // Return cached if valid
            if (siteCache && siteCache.timestamp && (now - siteCache.timestamp < CACHE_DURATION_MS)) {
                console.log("Serving coupons from cache for", domain);
                return resolve(siteCache.data);
            }
            
            // Otherwise "fetch" from backend (Mock for now until supabase is linked)
            console.log("Fetching new coupons for", domain);
            const mockCoupons = {
                "ajio.com": [
                    {id: "aj1", code: "SAVE500", title: "₹500 Off on orders above ₹1499", score: 82},
                    {id: "aj2", code: "NEW20", title: "20% Off for new users", score: 75}
                ],
                "amazon.in": [
                    {id: "am1", code: "HDFC10", title: "10% Instant Discount on HDFC Cards", score: 90}
                ],
                "flipkart.com": [
                    {id: "fk1", code: "BBD24", title: "Big Billion Days Special offer", score: 88}
                ]
            };
            
            const freshCoupons = mockCoupons[domain] || [];
            
            // Save to cache
            cache[domain] = {
                timestamp: now,
                data: freshCoupons
            };
            
            chrome.storage.local.set({ couponCache: cache }, () => {
                resolve(freshCoupons);
            });
        });
    });
}

// Listen for messages from content scripts or popups
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    console.log("Received message:", message);
    
    if (message.action === 'fetchCoupons') {
        const domain = message.domain;
        getCouponsForDomain(domain).then(coupons => {
            sendResponse({ success: true, coupons });
        });
        
        // Required for async sendResponse
        return true; 
    }
    
    if (message.action === 'voteCoupon') {
        const { id, vote } = message;
        console.log(`Vote received for coupon ${id}: ${vote}`);
        // In the future: Send this vote to Supabase/API
        sendResponse({ success: true });
        return false;
    }
    
    if (message.action === 'triggerNotification') {
        const { title, message: body } = message;
        chrome.notifications.create({
            type: 'basic',
            iconUrl: 'assets/icon128.png', 
            title: title,
            message: body,
            priority: 2
        });
        sendResponse({ success: true });
        return false;
    }
});
