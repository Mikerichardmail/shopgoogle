document.addEventListener('DOMContentLoaded', () => {
    const searchInput = document.getElementById('search-input');
    const resultsDiv = document.getElementById('results');
    const defaultView = document.getElementById('default-view');
    const submitView = document.getElementById('submit-view');
    const btnOptions = document.getElementById('btn-options');
    
    const trendingList = document.getElementById('trending-list');
    const btnShowSubmit = document.getElementById('btn-show-submit');
    const btnSubmitCoupon = document.getElementById('btn-submit-coupon');
    const btnCancelSubmit = document.getElementById('btn-cancel-submit');

    // Apply dark mode if setting enabled
    chrome.storage.local.get(['theme'], (result) => {
        if (result.theme === 'dark') document.body.classList.add('theme-dark');
    });

    btnOptions.addEventListener('click', () => {
        if (chrome.runtime.openOptionsPage) {
            chrome.runtime.openOptionsPage();
        } else {
            window.open(chrome.runtime.getURL('options.html'));
        }
    });

    // Mock Trending Deals
    const trendingDeals = [
        { store: "amazon.in", text: "Sale on Electronics!" },
        { store: "ajio.com", text: "New Users 20% Off" },
        { store: "flipkart.com", text: "BBD Pre-deals" }
    ];

    trendingList.innerHTML = trendingDeals.map(d => `<div style="padding: 5px; border-bottom: 1px solid #eee; font-size: 13px;"><strong>${d.store}</strong> • ${d.text}</div>`).join('');

    // Navigation Logic
    btnShowSubmit.addEventListener('click', () => {
        defaultView.style.display = 'none';
        resultsDiv.style.display = 'none';
        submitView.style.display = 'block';
    });

    btnCancelSubmit.addEventListener('click', () => {
        submitView.style.display = 'none';
        defaultView.style.display = 'block';
        searchInput.value = '';
    });

    btnSubmitCoupon.addEventListener('click', () => {
        alert("Thanks! Your coupon has been submitted for verification.");
        submitView.style.display = 'none';
        defaultView.style.display = 'block';
    });

    searchInput.addEventListener('input', (e) => {
        const query = e.target.value.toLowerCase().trim();
        if (!query) {
            defaultView.style.display = 'block';
            resultsDiv.style.display = 'none';
            return;
        }

        defaultView.style.display = 'none';
        submitView.style.display = 'none';
        resultsDiv.style.display = 'block';

        const matched = SUPPORTED_STORES.filter(store => store.includes(query));
        
        if (matched.length > 0) {
            resultsDiv.innerHTML = '<ul class="search-list">' + matched.map(s => `<li style="padding: 8px 0; border-bottom: 1px solid #eee;">Open ${s}</li>`).join('') + '</ul>';
        } else {
            resultsDiv.innerHTML = '<div class="empty-state"><p>No stores found.</p><button id="suggest-btn">Suggest this store?</button></div>';
            document.getElementById('suggest-btn').addEventListener('click', () => {
                alert('Thanks for suggesting ' + query + '!');
            });
        }
    });
});
